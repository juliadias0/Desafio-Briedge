import 'package:get/get.dart';
import 'package:parceiros_bridge/app/modules/bottom_navigation/bottom_navigation.dart';
import 'package:parceiros_bridge/app/modules/bridger/partner_listing/partner_listing_page.dart';
import 'package:parceiros_bridge/app/modules/bridger/bridger_qr_code/bridger_qr_code_page.dart';
import 'package:parceiros_bridge/app/modules/login/login_controller.dart';
import 'package:parceiros_bridge/app/modules/login/login_page.dart';
import 'package:parceiros_bridge/app/modules/partner/discount_listing/discount_listing_page.dart';
import 'package:parceiros_bridge/app/modules/partner/verify_bridger/verify_bridger_page.dart';
import 'package:parceiros_bridge/app/modules/profile/profile_page.dart';
import 'package:parceiros_bridge/app/modules/splash_screen/splash_screen_controller.dart';
import 'package:parceiros_bridge/app/modules/splash_screen/splash_screen_page.dart';

List<GetPage> getAppPages() {
  return [
    GetPage(
      name: SplashScreenPage.ROUTE,
      page: () => SplashScreenPage(),
      binding: BindingsBuilder(() => Get.lazyPut<SplashScreenController>(() => SplashScreenController())),
    ),
    GetPage(
      name: LoginPage.ROUTE,
      page: () => LoginPage(),
      binding: BindingsBuilder(() => Get.lazyPut<LoginController>(() => LoginController())),
    ),

    // Global bottom navigation (Bindings of bottom navigation initial pages are defined at bottom_navigation.dart)
    GetPage(name: BottomNavigation.ROUTE, page: () => BottomNavigation()),

    // Global profile page
    GetPage(name: ProfilePage.ROUTE, page: () => ProfilePage()),

    // Bridger user pages
    GetPage(name: PartnerListingPage.ROUTE, page: () => PartnerListingPage()),
    GetPage(name: BridgerQrCodePage.ROUTE, page: () => BridgerQrCodePage()),

    // Partner user pages
    GetPage(name: DiscountListingPage.ROUTE, page: () => DiscountListingPage()),
    GetPage(name: VerifyBridgerPage.ROUTE, page: () => VerifyBridgerPage()),
  ];
}

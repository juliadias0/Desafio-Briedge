import 'package:flutter/material.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';

class PrimaryButton extends StatelessWidget {
  final Widget child;
  final VoidCallback? onPressed;

  const PrimaryButton({
    Key? key,
    required this.child,
    required this.onPressed,
  }) : super(key: key);

  factory PrimaryButton.icon({
    Key? key,
    required Widget icon,
    required Widget label,
    VoidCallback? onPressed,
  }) =>
      PrimaryButton(
        key: key,
        onPressed: onPressed,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            icon,
            const SizedBox(width: 8),
            label,
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SizedBox(
      height: 48,
      child: MaterialButton(
        animationDuration: Duration(seconds: 1),
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        color: theme.colorScheme.primary,
        elevation: 0,
        onPressed: onPressed,
        disabledColor: AppColors.blackDisabled,
        disabledTextColor: AppColors.whiteDisabled,
        child: IconTheme.merge(
          data: IconThemeData(color: Colors.white, size: 24),
          child: DefaultTextStyle.merge(
            child: child,
            style: const TextStyle(color: Colors.white),
          ),
        ),
      ),
    );
  }
}

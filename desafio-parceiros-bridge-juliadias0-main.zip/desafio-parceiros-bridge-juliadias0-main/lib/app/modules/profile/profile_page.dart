import 'package:flutter/material.dart';
import 'package:parceiros_bridge/app/core/globals/auth_controller.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:parceiros_bridge/app/core/utils/date_time_utils.dart';
import 'package:parceiros_bridge/app/core/utils/snackbar.dart';
import 'package:parceiros_bridge/app/data/enums/user_type.dart';
import 'package:get/get.dart';
import 'package:parceiros_bridge/app/modules/bottom_navigation/bottom_navigation.dart';
import 'package:parceiros_bridge/app/modules/login/login_page.dart';

class ProfilePage extends StatelessWidget {
  static const ROUTE = '${BottomNavigation.ROUTE}/profile';

  const ProfilePage();

  @override
  Widget build(BuildContext context) {
    final user = AuthController.instance.user;
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: Text('Perfil')),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image(
                image: AssetImage('assets/images/profile/generic_profile_picture.png'),
                width: Get.width / 3,
              ),
            ),
            SizedBox(height: 24),
            Text.rich(
              TextSpan(
                style: textTheme.bodyText2?.copyWith(color: AppColors.grey700),
                children: [
                  TextSpan(text: 'Nome:'),
                  WidgetSpan(child: SizedBox(width: 4)),
                  TextSpan(text: user.value.nickname, style: textTheme.bodyText1),
                ],
              ),
            ),
            SizedBox(height: 4),
            Text.rich(
              TextSpan(
                style: textTheme.bodyText2?.copyWith(color: AppColors.grey700),
                children: [
                  TextSpan(text: 'Email:'),
                  WidgetSpan(child: SizedBox(width: 4)),
                  TextSpan(text: user.value.email, style: textTheme.bodyText1),
                ],
              ),
            ),
            SizedBox(height: 4),
            Text.rich(
              TextSpan(
                style: textTheme.bodyText2?.copyWith(color: AppColors.grey700),
                children: [
                  TextSpan(text: 'Tipo de usuário:'),
                  WidgetSpan(child: SizedBox(width: 4)),
                  TextSpan(text: user.value.userType.name, style: textTheme.bodyText1),
                ],
              ),
            ),
            SizedBox(height: 4),
            Text.rich(
              TextSpan(
                style: textTheme.bodyText2?.copyWith(color: AppColors.grey700),
                children: [
                  TextSpan(text: 'Data de nascimento:'),
                  WidgetSpan(child: SizedBox(width: 4)),
                  TextSpan(text: user.value.birthDate.formatedToddMMyyyy, style: textTheme.bodyText1),
                ],
              ),
            ),
            SizedBox(height: 4),
            Text.rich(
              TextSpan(
                style: textTheme.bodyText2?.copyWith(color: AppColors.grey700),
                children: [
                  TextSpan(text: 'Data de cadastro:'),
                  WidgetSpan(child: SizedBox(width: 4)),
                  TextSpan(text: user.value.registrationDate.formatedToddMMyyyy, style: textTheme.bodyText1),
                ],
              ),
            ),
            SizedBox(height: 4),
            Text.rich(
              TextSpan(
                style: textTheme.bodyText2?.copyWith(color: AppColors.grey700),
                children: [
                  TextSpan(text: 'Ultimo login:'),
                  WidgetSpan(child: SizedBox(width: 4)),
                  TextSpan(text: user.value.lastLoginDate.formatedToddMMyyyy, style: textTheme.bodyText1),
                ],
              ),
            ),
            SizedBox(height: 24),
            RawMaterialButton(
              splashColor: AppColors.grey600,
              child: Column(
                children: [
                  Divider(height: 1),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Row(
                      children: [
                        Icon(Icons.edit_outlined, color: Colors.black),
                        SizedBox(width: 24),
                        Text('Editar informações'),
                        Expanded(child: SizedBox()),
                        Icon(Icons.chevron_right, color: AppColors.grey600),
                      ],
                    ),
                  ),
                ],
              ),
              onPressed: () => showGetSnackbar(text: 'Em desenvolvimento'),
            ),
            RawMaterialButton(
              splashColor: AppColors.grey600,
              child: Column(
                children: [
                  Divider(height: 1),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Row(
                      children: [
                        Icon(Icons.logout, color: Colors.black),
                        SizedBox(width: 24),
                        Text('Sair'),
                        Expanded(child: SizedBox()),
                        Icon(Icons.chevron_right, color: AppColors.grey600),
                      ],
                    ),
                  ),
                  Divider(height: 1),
                ],
              ),
              onPressed: () => showDialogOnLogoutPressed(context),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> showDialogOnLogoutPressed(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Sair do aplicativo?'),
        content: Text('Ao confirmar, sua sessão será encerrada.'),
        actions: <Widget>[
          TextButton(
            child: Text('Cancelar', style: TextStyle(color: AppColors.blackInactive)),
            onPressed: Get.back,
          ),
          TextButton(
            child: Text('Confirmar'),
            onPressed: () => Get.offAllNamed(LoginPage.ROUTE),
          ),
        ],
      ),
    );
  }
}

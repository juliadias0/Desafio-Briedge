import 'package:get/get.dart';
import 'package:parceiros_bridge/app/data/model/partner/partner_discount.dart';
import 'package:parceiros_bridge/app/data/services/partner_service.dart' as partnerService;

class DiscountListingController extends GetxController {
  final RxBool isLoading = true.obs;
  final RxList<PartnerDiscount> partnerDiscounts = <PartnerDiscount>[].obs;

  @override
  Future<void> onInit() async {
    onRefresh();
    super.onInit();
  }

  Future<void> onRefresh() async {
    isLoading.value = true;

    try {
      final partnerDiscountsRaw = await Future.wait(partnerService.getPartnerDiscountsList());
      final partnerDiscountsList = partnerDiscountsRaw.map<PartnerDiscount>((p) => PartnerDiscount.fromJson(p ?? <String, dynamic>{})).toList();

      partnerDiscounts.value = partnerDiscountsList;
    } on Exception catch (_) {
      partnerDiscounts.value = <PartnerDiscount>[];
    }

    await Future.delayed(Duration(seconds: 1));
    isLoading.value = false;
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:parceiros_bridge/app/data/model/partner/partner_discount.dart';
import 'package:parceiros_bridge/app/core/utils/date_time_utils.dart';

class DiscountItem extends StatelessWidget {
  final PartnerDiscount partnerDiscount;

  const DiscountItem({
    required this.partnerDiscount,
  });

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Padding(
      padding: EdgeInsets.only(bottom: 24, right: 24),
      child: Stack(
        alignment: Alignment.centerLeft,
        fit: StackFit.passthrough,
        children: [
          Image.asset(
            'assets/images/discount/discount_rectangle.png',
            height: Get.height / 8,
            fit: BoxFit.fill,
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            child: IntrinsicHeight(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      '${partnerDiscount.discountPercentage}%',
                      style: textTheme.headline4?.copyWith(color: AppColors.grey600, fontWeight: FontWeight.w500),
                    ),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(partnerDiscount.description, maxLines: 2, overflow: TextOverflow.fade),
                        SizedBox(height: 8),
                        Text.rich(
                          TextSpan(
                            style: textTheme.bodyText2?.copyWith(color: AppColors.grey600),
                            children: [
                              TextSpan(text: 'Data de criação:'),
                              WidgetSpan(child: SizedBox(width: 4)),
                              TextSpan(text: partnerDiscount.createdDate.formatedToddMMyyyy, style: textTheme.caption),
                            ],
                          ),
                          maxLines: 1,
                          softWrap: false,
                          overflow: TextOverflow.fade,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

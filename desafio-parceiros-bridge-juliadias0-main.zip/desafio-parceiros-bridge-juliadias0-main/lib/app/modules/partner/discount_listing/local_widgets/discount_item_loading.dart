import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:shimmer/shimmer.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DiscountItemLoading extends StatelessWidget {
  const DiscountItemLoading();

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
        baseColor: AppColors.grey300,
        highlightColor: AppColors.whiteSmoke,
        child: Padding(
          padding: EdgeInsets.only(bottom: 24, right: 24),
          child: Image.asset(
            'assets/images/discount/discount_rectangle.png',
            height: Get.height / 8,
            fit: BoxFit.fill,
          ),
        ));
  }
}

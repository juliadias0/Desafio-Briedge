import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:parceiros_bridge/app/core/globals/auth_controller.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:parceiros_bridge/app/modules/bottom_navigation/bottom_navigation.dart';
import 'package:get/get.dart';
import 'package:parceiros_bridge/app/modules/partner/discount_listing/discount_listing_controller.dart';
import 'package:parceiros_bridge/app/modules/partner/discount_listing/local_widgets/discount_item.dart';
import 'package:parceiros_bridge/app/modules/partner/discount_listing/local_widgets/discount_item_loading.dart';

class DiscountListingPage extends GetView<DiscountListingController> {
  static const ROUTE = '${BottomNavigation.ROUTE}/discount_listing';

  const DiscountListingPage();

  @override
  Widget build(BuildContext context) {
    final user = AuthController.instance.user.value;
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de descontos'),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(vertical: 24, horizontal: 16),
        child: Obx(
          () => RefreshIndicator(
            onRefresh: controller.onRefresh,
            color: AppColors.bridgeColor,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Olá, ${user.nickname}!', style: textTheme.headline4),
                SizedBox(height: 4),
                Text(
                  'Abaixo estão listados todos os seus descontos ativos no momento. Você pode criar um novo ou editar/excluir um existente',
                  style: textTheme.subtitle1,
                ),
                SizedBox(height: 32),
                Expanded(
                  child: AnimationLimiter(
                    child: ListView.builder(
                      itemCount: controller.isLoading.value ? 6 : controller.partnerDiscounts.length,
                      itemBuilder: (context, index) {
                        return AnimationConfiguration.staggeredList(
                          position: index,
                          duration: const Duration(milliseconds: 375),
                          child: SlideAnimation(
                            child: FadeInAnimation(
                              child: controller.isLoading.value
                                  ? DiscountItemLoading()
                                  : DiscountItem(
                                      partnerDiscount: controller.partnerDiscounts.elementAt(index),
                                    ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

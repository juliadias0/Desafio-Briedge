import 'package:flutter/material.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:parceiros_bridge/app/core/utils/snackbar.dart';
import 'package:parceiros_bridge/app/modules/bottom_navigation/bottom_navigation.dart';
import 'package:get/get.dart';

class VerifyBridgerPage extends StatelessWidget {
  static const ROUTE = '${BottomNavigation.ROUTE}/scanner_page';

  const VerifyBridgerPage();

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
        title: Text('Verificação de identidade'),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 16, top: 48, right: 16, bottom: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Bridger a vista?', style: textTheme.headline4),
            SizedBox(height: 4),
            Text(
              'Verifique o QR code ou digite o identificador único do bridger para confirmar que ele é realmente um colaborador',
              style: textTheme.subtitle1,
            ),
            Expanded(child: SizedBox()),
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: Get.width / 1.3,
                    height: 64,
                    child: OutlinedButton.icon(
                      style: ButtonStyle(
                        side: MaterialStateProperty.all(BorderSide(color: AppColors.bridgeColor, width: 2.0)),
                      ),
                      icon: Icon(Icons.qr_code_scanner_outlined, color: AppColors.grey800),
                      label: Text('Escanear QR Code', style: textTheme.button?.copyWith(color: AppColors.grey800)),
                      onPressed: () => showGetSnackbar(text: 'Em desenvolvimento'),
                    ),
                  ),
                  SizedBox(height: 24),
                  Container(
                    width: Get.width / 1.3,
                    height: 64,
                    child: OutlinedButton.icon(
                      style: ButtonStyle(
                        side: MaterialStateProperty.all(BorderSide(color: AppColors.bridgeColor, width: 2.0)),
                      ),
                      icon: Icon(Icons.keyboard_alt_outlined, color: AppColors.grey800),
                      label: Text('Digitar identificador', style: textTheme.button?.copyWith(color: AppColors.grey800)),
                      onPressed: () => showGetSnackbar(text: 'Em desenvolvimento'),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(child: SizedBox()),
          ],
        ),
      ),
    );
  }
}

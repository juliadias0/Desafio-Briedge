import 'package:flutter/material.dart';
import 'package:parceiros_bridge/app/core/globals/auth_controller.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:parceiros_bridge/app/data/enums/user_type.dart';
import 'package:parceiros_bridge/app/modules/bridger/partner_listing/partner_listing_page.dart';
import 'package:parceiros_bridge/app/modules/bridger/bridger_qr_code/bridger_qr_code_page.dart';
import 'package:parceiros_bridge/app/modules/partner/discount_listing/discount_listing_page.dart';
import 'package:parceiros_bridge/app/modules/partner/verify_bridger/verify_bridger_page.dart';
import 'package:parceiros_bridge/app/modules/profile/profile_page.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';

class BottomNavigation extends StatelessWidget {
  static const ROUTE = '/bridger/tabs';

  const BottomNavigation();

  @override
  Widget build(BuildContext context) {
    final userType = AuthController.instance.user.value.userType;
    final tabController = PersistentTabController();
    return PersistentTabView(
      context,
      controller: tabController,
      screens: [
        if (userType == UserType.partner) ...[
          DiscountListingPage(),
          VerifyBridgerPage(),
        ] else ...[
          PartnerListingPage(),
          BridgerQrCodePage(),
        ],
        ProfilePage(),
      ],
      items: [
        PersistentBottomNavBarItem(
          icon: Icon(Icons.list_outlined),
          title: userType == UserType.partner ? 'Meus Descontos' : 'Parceiros',
          activeColorPrimary: AppColors.bridgeColor,
          inactiveColorPrimary: AppColors.blackInactive,
        ),
        PersistentBottomNavBarItem(
          icon: Icon(Icons.qr_code_outlined),
          title: userType == UserType.partner ? 'Verificar QR' : 'Meu QR',
          activeColorPrimary: AppColors.bridgeColor,
          inactiveColorPrimary: AppColors.blackInactive,
        ),
        PersistentBottomNavBarItem(
          icon: Icon(Icons.account_circle),
          title: 'Perfil',
          activeColorPrimary: AppColors.bridgeColor,
          inactiveColorPrimary: AppColors.blackInactive,
        ),
      ],
      backgroundColor: AppColors.whiteSmoke,
      itemAnimationProperties: ItemAnimationProperties(duration: Duration(milliseconds: 200), curve: Curves.ease),
      screenTransitionAnimation: ScreenTransitionAnimation(animateTabTransition: true, curve: Curves.ease, duration: Duration(milliseconds: 200)),
      navBarStyle: NavBarStyle.style3,
    );
  }
}

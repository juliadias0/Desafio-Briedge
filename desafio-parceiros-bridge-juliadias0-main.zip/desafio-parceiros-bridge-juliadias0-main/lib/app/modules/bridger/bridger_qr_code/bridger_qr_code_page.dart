import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:parceiros_bridge/app/core/globals/auth_controller.dart';
import 'package:parceiros_bridge/app/modules/bottom_navigation/bottom_navigation.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:get/get.dart';

class BridgerQrCodePage extends StatelessWidget {
  static const ROUTE = '${BottomNavigation.ROUTE}/bridger_qr_code';

  const BridgerQrCodePage();

  @override
  Widget build(BuildContext context) {
    final user = AuthController.instance.user.value;
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
        title: Text('Meu QR Code'),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(vertical: 24, horizontal: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Olá, ${user.nickname}!', style: textTheme.headline4),
            SizedBox(height: 4),
            Text(
              'Este é o seu QRCode. Nele estão contidos alguns dos seus dados de usuário. Use-o nos estabelecimentos parceiros do bridge para confirmar que você é um bridger',
              style: textTheme.subtitle1,
            ),
            Expanded(child: SizedBox()),
            Center(
              child: QrImage(
                data: json.encode(user.toQrCodeJson()),
                version: QrVersions.auto,
                size: Get.width / 1.7,
              ),
            ),
            Expanded(child: SizedBox()),
          ],
        ),
      ),
    );
  }
}

import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:shimmer/shimmer.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PartnerItemLoading extends StatelessWidget {
  const PartnerItemLoading();

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: AppColors.grey300,
      highlightColor: AppColors.whiteSmoke,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(height: Get.width / 9, width: Get.width / 9, color: AppColors.grey600),
              SizedBox(width: 16),
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(height: 10, width: Get.width / 1.4, color: AppColors.grey600),
                  SizedBox(height: 4),
                  Container(height: 10, width: Get.width / 1.4, color: AppColors.grey600),
                  SizedBox(height: 4),
                  Container(height: 10, width: Get.width / 8, color: AppColors.grey600),
                ],
              ),
            ],
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Divider(height: 1),
          ),
        ],
      ),
    );
  }
}

import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:parceiros_bridge/app/data/model/partner/partner.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PartnerItem extends StatelessWidget {
  final Partner partner;

  const PartnerItem({
    required this.partner,
  });

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(partner.profilePicture, height: Get.width / 9, width: Get.width / 9),
            SizedBox(width: 16),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text.rich(
                  TextSpan(
                    style: textTheme.bodyText2?.copyWith(color: AppColors.grey600),
                    children: [
                      TextSpan(text: 'Nome:'),
                      WidgetSpan(child: SizedBox(width: 4)),
                      TextSpan(text: partner.name, style: textTheme.subtitle1),
                    ],
                  ),
                ),
                SizedBox(height: 4),
                Text.rich(
                  TextSpan(
                    style: textTheme.bodyText2?.copyWith(color: AppColors.grey600),
                    children: [
                      TextSpan(text: 'Local:'),
                      WidgetSpan(child: SizedBox(width: 4)),
                      TextSpan(text: partner.location, style: textTheme.caption),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
        Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Divider(height: 1),
        ),
      ],
    );
  }
}

import 'package:get/get.dart';
import 'package:parceiros_bridge/app/data/model/partner/partner.dart';
import 'package:parceiros_bridge/app/data/services/partner_service.dart' as partnerService;

class PartnerListingController extends GetxController {
  final RxBool isLoading = true.obs;
  final RxList<Partner> partners = <Partner>[].obs;

  @override
  Future<void> onInit() async {
    onRefresh();
    super.onInit();
  }

  Future<void> onRefresh({bool isOnInit = false}) async {
    isLoading.value = true;

    try {
      final partnersRaw = await Future.wait(partnerService.getPartnersList());
      final partnersList = partnersRaw.map<Partner>((p) => Partner.fromJson(p ?? <String, dynamic>{})).toList();

      partners.value = partnersList;
    } on Exception catch (_) {
      partners.value = <Partner>[];
    }

    await Future.delayed(Duration(seconds: 1));
    isLoading.value = false;
  }
}

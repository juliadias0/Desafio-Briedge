import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:parceiros_bridge/app/modules/bridger/partner_listing/local_widgets/partner_item_loading.dart';
import 'package:parceiros_bridge/app/modules/bottom_navigation/bottom_navigation.dart';
import 'package:get/get.dart';
import 'package:parceiros_bridge/app/modules/bridger/partner_listing/partner_listing_controller.dart';
import 'package:parceiros_bridge/app/modules/bridger/partner_listing/local_widgets/partner_item.dart';

class PartnerListingPage extends GetView<PartnerListingController> {
  static const ROUTE = '${BottomNavigation.ROUTE}/partner_listing';

  const PartnerListingPage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de parceiros'),
      ),
      body: Padding(
        padding: EdgeInsets.only(top: 16),
        child: Obx(
          () => RefreshIndicator(
            onRefresh: controller.onRefresh,
            color: AppColors.bridgeColor,
            child: AnimationLimiter(
              child: ListView.builder(
                padding: EdgeInsets.symmetric(vertical: 32, horizontal: 16),
                itemCount: controller.isLoading.value ? 8 : controller.partners.length,
                itemBuilder: (context, index) {
                  return AnimationConfiguration.staggeredList(
                    position: index,
                    duration: const Duration(milliseconds: 375),
                    child: SlideAnimation(
                      child: FadeInAnimation(
                        child: controller.isLoading.value
                            ? PartnerItemLoading()
                            : PartnerItem(
                                partner: controller.partners.elementAt(index),
                              ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}

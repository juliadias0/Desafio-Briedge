import 'package:get/get.dart';
import 'package:parceiros_bridge/app/modules/login/login_page.dart';

class SplashScreenController extends GetxController {
  SplashScreenController();

  RxBool isLoaded = false.obs;

  @override
  Future<void> onInit() async {
    await Future.delayed(Duration(seconds: 1));
    isLoaded.value = true;

    super.onInit();

    await Future.delayed(Duration(seconds: 1));
    Get.offAllNamed(LoginPage.ROUTE);
  }
}

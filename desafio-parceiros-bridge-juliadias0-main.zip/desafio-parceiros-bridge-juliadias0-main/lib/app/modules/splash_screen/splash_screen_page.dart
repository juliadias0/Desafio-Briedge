import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:parceiros_bridge/app/modules/splash_screen/splash_screen_controller.dart';

class SplashScreenPage extends GetView<SplashScreenController> {
  static const ROUTE = '/splash_screen';

  const SplashScreenPage();

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Container(
      color: Colors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image(image: AssetImage('assets/images/logo/parceiros_logo.png')),
          SizedBox(height: 36),
          Obx(
            () => controller.isLoaded.value
                ? Text('Bem vindo!', style: textTheme.headline4?.copyWith(fontWeight: FontWeight.w400))
                : CircularProgressIndicator(strokeWidth: 2, color: AppColors.bridgeColor),
          ),
        ],
      ),
    );
  }
}

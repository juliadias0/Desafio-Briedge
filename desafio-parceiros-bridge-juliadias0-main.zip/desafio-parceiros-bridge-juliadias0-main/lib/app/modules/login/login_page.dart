import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';
import 'package:parceiros_bridge/app/core/theme/form_field_input_decoration.dart';
import 'package:parceiros_bridge/app/core/utils/snackbar.dart';
import 'package:parceiros_bridge/app/data/model/user/user_mock.dart';
import 'package:parceiros_bridge/app/global_widgets/primary_button.dart';
import 'package:get/get.dart';
import 'package:parceiros_bridge/app/modules/login/login_controller.dart';

class LoginPage extends GetView<LoginController> {
  static const ROUTE = '/login';

  const LoginPage();

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final loginFormKey = GlobalKey<FormState>();
    return Scaffold(
      body: Container(
        color: AppColors.bridgeColor,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Expanded(
              flex: 1,
              child: Image(image: AssetImage('assets/images/logo/bridge_logo_small.png')),
            ),
            Expanded(
              flex: 2,
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
                  color: AppColors.whiteSmoke,
                ),
                child: Padding(
                  padding: EdgeInsets.only(left: 16, right: 16),
                  child: SingleChildScrollView(
                    child: Form(
                      key: loginFormKey,
                      child: Column(
                        children: [
                          SizedBox(height: 24),
                          Text('Faça seu login', style: textTheme.headline6?.copyWith(fontWeight: FontWeight.w500)),
                          SizedBox(height: 84),
                          TextFormField(
                            decoration: getTextFieldDecoration(context: context, enabled: true, label: 'Email', isInvalid: false),
                            validator: (email) => email == null || email.isEmpty ? 'Campo obrigatório' : null,
                            initialValue: kReleaseMode ? null : users.elementAt(1).email,
                            onSaved: controller.onEmailFormChanged,
                          ),
                          SizedBox(height: 16),
                          Obx(
                            () => TextFormField(
                              obscureText: controller.obscurePassword.value,
                              decoration: getTextFieldDecoration(context: context, enabled: true, label: 'Senha', isInvalid: false).copyWith(
                                suffixIcon: IconButton(
                                  icon: Icon(controller.obscurePassword.value ? Icons.visibility : Icons.visibility_off),
                                  onPressed: () => controller.obscurePassword.value = !controller.obscurePassword.value,
                                ),
                              ),
                              validator: (password) => password == null || password.isEmpty ? 'Campo obrigatório' : null,
                              initialValue: kReleaseMode ? null : users.elementAt(1).password,
                              onSaved: controller.onPasswordFormChanged,
                            ),
                          ),
                          SizedBox(height: 4),
                          Obx(
                            () => controller.incorrectCredentials.value
                                ? Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      'Usuário ou senha incorretos',
                                      style: textTheme.caption?.copyWith(color: AppColors.red900),
                                    ),
                                  )
                                : SizedBox(),
                          ),
                          SizedBox(height: 24),
                          SizedBox(
                            height: 48,
                            child: Obx(
                              () => AnimatedSwitcher(
                                duration: const Duration(milliseconds: 200),
                                child: controller.isLoading.value
                                    ? Center(child: CircularProgressIndicator())
                                    : SizedBox(
                                        width: double.infinity,
                                        child: PrimaryButton(
                                          child: Text('Conectar'),
                                          onPressed: () => onConnectPressed(loginFormKey),
                                        ),
                                      ),
                              ),
                            ),
                          ),
                          TextButton(
                            child: Text('Esqueceu sua senha?', style: textTheme.caption?.copyWith(color: AppColors.bridgeColor)),
                            onPressed: () => showGetSnackbar(text: 'Em desenvolvimento'),
                          ),
                          SizedBox(height: 24),
                          Text.rich(
                            TextSpan(
                              style: textTheme.caption,
                              children: [
                                TextSpan(text: 'Não é cadastrado?'),
                                WidgetSpan(child: SizedBox(width: 4)),
                                WidgetSpan(
                                  child: InkWell(
                                    child: Text('Crie uma conta', style: TextStyle(color: AppColors.bridgeColor)),
                                    onTap: () => showGetSnackbar(text: 'Em desenvolvimento'),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 56),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void onConnectPressed(GlobalKey<FormState> loginFormKey) {
    controller.incorrectCredentials.value = false;
    loginFormKey.currentState?.save();

    final isValid = loginFormKey.currentState?.validate();
    if (isValid != null && isValid) {
      controller.executeLogin();
    }
  }
}

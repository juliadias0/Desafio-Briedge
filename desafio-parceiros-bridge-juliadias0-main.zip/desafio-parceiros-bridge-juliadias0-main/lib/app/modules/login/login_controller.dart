import 'package:get/get.dart';
import 'package:parceiros_bridge/app/core/globals/auth_controller.dart';
import 'package:parceiros_bridge/app/data/enums/user_type.dart';
import 'package:parceiros_bridge/app/data/model/login_form/login_form.dart';
import 'package:parceiros_bridge/app/data/model/user/user_mock.dart';
import 'package:parceiros_bridge/app/modules/bottom_navigation/bottom_navigation.dart';
import 'package:parceiros_bridge/app/modules/bridger/partner_listing/partner_listing_controller.dart';
import 'package:parceiros_bridge/app/modules/partner/discount_listing/discount_listing_controller.dart';

class LoginController extends GetxController {
  final RxBool isLoading = false.obs;
  final RxBool incorrectCredentials = false.obs;
  final RxBool obscurePassword = true.obs;
  final Rx<LoginForm> loginForm = LoginForm().obs;

  Future<void> executeLogin() async {
    isLoading.value = true;

    // ignore: unnecessary_cast
    final user = users.where((user) => user.email == loginForm.value.email && user.password == loginForm.value.password).toList();

    await Future.delayed(Duration(seconds: 2));
    isLoading.value = false;

    if (user.length != 1) {
      incorrectCredentials.value = true;
      return;
    }

    final authController = AuthController.instance;
    if (authController.isUserAlreadySet.value) {
      authController.user.value = user.first;
    } else {
      authController.user = user.first.obs;
      authController.isUserAlreadySet.value = true;
    }

    switch (authController.user.value.userType) {
      case UserType.partner:
        Get.lazyPut<DiscountListingController>(() => DiscountListingController());
        break;
      default:
        Get.lazyPut<PartnerListingController>(() => PartnerListingController());
        break;
    }

    Get.offAllNamed(BottomNavigation.ROUTE);
  }

  void onEmailFormChanged(String? newEmail) {
    loginForm.value = loginForm.value.copyWith(email: newEmail);
  }

  void onPasswordFormChanged(String? newPassword) {
    loginForm.value = loginForm.value.copyWith(password: newPassword);
  }
}

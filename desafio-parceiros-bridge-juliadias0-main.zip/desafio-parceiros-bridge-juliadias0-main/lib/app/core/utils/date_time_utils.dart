import 'package:get/get.dart';
import 'package:intl/intl.dart';

extension DateTimeUtils on DateTime {
  static final _monthToName = <String>[
    'janeiro',
    'fevereiro',
    'março',
    'abril',
    'maio',
    'junho',
    'julho',
    'agosto',
    'setembro',
    'outubro',
    'novembro',
    'dezembro',
  ];

  DateTime get firstDayOfMonth => DateTime(year, month, 1);

  String get monthName => _monthToName[month - 1];

  String getDateRange(DateTime date) {
    if (month == date.month) {
      return '${monthName.capitalize} de $year';
    }

    return '${monthName.capitalize} de $year e ${date.monthName.capitalizeFirst} de ${date.year}';
  }

  String get formatedToddMMyyyy => DateFormat('dd/MM/yyyy').format(this);
}

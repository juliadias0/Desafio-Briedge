import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';

Future<SnackBarClosedReason> showMaterialSnackbar({
  required BuildContext context,
  required Widget content,
}) {
  final scaffoldMessenger = ScaffoldMessenger.of(context)..hideCurrentSnackBar();
  return scaffoldMessenger
      .showSnackBar(
        SnackBar(
          content: content,
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppColors.blackSurface,
          elevation: 6,
        ),
      )
      .closed;
}

void showGetSnackbar({
  required String text,
  String? buttonText,
  SnackPosition position = SnackPosition.BOTTOM,
  Duration duration = const Duration(seconds: 1),
}) {
  if (Get.isSnackbarOpen ?? false) Get.back();

  Get.rawSnackbar(
    snackPosition: position,
    duration: duration,
    borderRadius: 4,
    backgroundColor: AppColors.blackSurface,
    margin: const EdgeInsets.fromLTRB(8, 0, 8, 16),
    padding: const EdgeInsets.all(16),
    messageText: Text(text, style: Get.theme.textTheme.caption!.copyWith(color: Colors.white)),
    mainButton: buttonText == null
        ? null
        : TextButton(
            child: Text(buttonText, style: Get.theme.textTheme.caption!.copyWith(color: Colors.white)),
            onPressed: () => Get.back(),
          ),
  );
}

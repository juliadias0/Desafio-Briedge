import 'package:flutter/material.dart';

import 'package:parceiros_bridge/app/core/theme/app_colors.dart';

ColorScheme createColorScheme() {
  return const ColorScheme(
    primary: AppColors.bridgeColor,
    primaryVariant: Color(0xFF007ACC),
    secondary: AppColors.bridgeColor,
    secondaryVariant: Color(0xFFC0CFFF),
    background: AppColors.whiteSmoke,
    surface: Color(0xFFFFFFFF),
    error: AppColors.red700,
    onPrimary: Color(0xFFFFFFFF),
    onSecondary: Color(0xFF212121),
    onBackground: Color(0xFF212121),
    onSurface: Color(0xFF304FFE),
    onError: Color(0xFFFFFFFF),
    brightness: Brightness.light,
  );
}

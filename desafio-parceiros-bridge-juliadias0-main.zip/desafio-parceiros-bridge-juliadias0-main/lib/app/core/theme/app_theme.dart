import 'package:flutter/material.dart';

import 'package:parceiros_bridge/app/core/theme/color_theme.dart';
import 'package:parceiros_bridge/app/core/theme/text_theme.dart';
import 'package:parceiros_bridge/app/core/theme/app_colors.dart';

ThemeData createTheme() {
  final theme = ThemeData.from(colorScheme: createColorScheme());

  final lightTextTheme = createTextTheme(Brightness.light);
  final darkTextTheme = createTextTheme(Brightness.dark);

  return theme.copyWith(
    textTheme: lightTextTheme,
    primaryTextTheme: darkTextTheme,
    dividerTheme: const DividerThemeData(space: 0, color: AppColors.grey300),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: AppColors.bridgeColor),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(side: BorderSide(color: AppColors.bridgeColor))),
    iconTheme: IconThemeData(color: Colors.white),
  );
}

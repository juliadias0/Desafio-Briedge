import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:parceiros_bridge/app/core/globals/auth_controller.dart';

class GlobalBindings extends Bindings {
  final Dio? dio;

  GlobalBindings({this.dio});

  @override
  void dependencies() {
    Get.put<AuthController>(AuthController(), permanent: true);
  }
}

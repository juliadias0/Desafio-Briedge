import 'package:parceiros_bridge/app/data/provider/partner_api.dart' as partnerApi;

List<Future<Map<String, dynamic>?>> getPartnersList() {
  return List<Future<Map<String, dynamic>?>>.generate(4, (i) => partnerApi.getPartnersList());
}

List<Future<Map<String, dynamic>?>> getPartnerDiscountsList() {
  return List<Future<Map<String, dynamic>?>>.generate(5, (i) => partnerApi.getPartnerDiscountsList());
}

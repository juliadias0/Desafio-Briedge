const adminName = 'Administrador';
const bridgerName = 'Bridger';
const partnerName = 'Parceiro bridge';

enum UserType {
  admin,
  bridger,
  partner,
}

extension UserTypeData on UserType {
  String get name {
    switch (this) {
      case UserType.admin:
        return adminName;
      case UserType.bridger:
        return bridgerName;
      case UserType.partner:
        return partnerName;
    }
  }
}

UserType getUserTypeByName(String name) {
  switch (name) {
    case adminName:
      return UserType.admin;
    case partnerName:
      return UserType.partner;
    case bridgerName:
    default:
      return UserType.bridger;
  }
}

import 'dart:math';

import 'package:dio/dio.dart';
import 'package:parceiros_bridge/app/core/utils/snackbar.dart';

Future<Map<String, dynamic>?> getPartnersList() async {
  try {
    final userRandomResponse = await Dio().get('https://randomuser.me/api/');
    final userData = userRandomResponse.data['results'].first ?? <String, dynamic>{};

    final randomProfilePicture = await Dio().get('https://dog.ceo/api/breeds/image/random');
    final profilePictureData = randomProfilePicture.data ?? <String, dynamic>{};

    return {
      'name': userData['login']['username'],
      'profilePicture': profilePictureData['message'],
      'location': userData['location']['street']['name'],
    };
  } on Exception catch (e) {
    print('[PartnerApi] - getPartnersList error: $e');
    showGetSnackbar(text: 'Ops, houve um problema ao carregar a lista de parceiros.');
    return null;
  }
}

Future<Map<String, dynamic>?> getPartnerDiscountsList() async {
  final randomPartnerDiscountMessages = [
    'Em coxinhas de catupiry',
    'Em um café expresso',
    'Em um sanduiche de atum',
    'Na compra de um pastel de carne',
    'Na compra de um suco de uva',
  ];

  try {
    final discountResponse = await Dio().get('https://csrng.net/csrng/csrng.php?min=0&max=60');
    final discountData = discountResponse.data.first ?? <String, dynamic>{};

    return {
      'discountPercentage': discountData['random'],
      'description': randomPartnerDiscountMessages.elementAt(Random().nextInt(5)),
      'createdDate': DateTime(2021, Random().nextInt(13), Random().nextInt(31)).toIso8601String(),
    };
  } on Exception catch (e) {
    print('[PartnerApi] - getPartnersList error: $e');
    showGetSnackbar(text: 'Ops, houve um problema ao carregar a lista de parceiros.');
    return null;
  }
}

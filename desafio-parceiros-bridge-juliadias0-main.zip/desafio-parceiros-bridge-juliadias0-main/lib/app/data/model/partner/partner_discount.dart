class PartnerDiscount {
  final double discountPercentage;
  final String description;
  final DateTime createdDate;

  const PartnerDiscount({
    required this.discountPercentage,
    required this.description,
    required this.createdDate,
  });

  static PartnerDiscount fromJson(Map<String, dynamic> json) {
    return PartnerDiscount(
      discountPercentage: (json['discountPercentage'] as int).toDouble(),
      description: json['description'],
      createdDate: json.containsKey('createdDate') ? DateTime.parse(json['createdDate']) : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['discountPercentage'] = discountPercentage;
    data['description'] = description;
    data['createdDate'] = createdDate;

    return data;
  }
}

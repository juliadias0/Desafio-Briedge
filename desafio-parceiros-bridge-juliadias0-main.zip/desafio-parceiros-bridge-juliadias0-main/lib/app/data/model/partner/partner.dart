class Partner {
  final String name;
  final String profilePicture;
  final String location;

  const Partner({
    required this.name,
    required this.profilePicture,
    required this.location,
  });

  static Partner fromJson(Map<String, dynamic> json) {
    return Partner(
      name: json['name'],
      profilePicture: json['profilePicture'],
      location: json['location'],
    );
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['name'] = name;
    data['profilePicture'] = profilePicture;
    data['location'] = location;

    return data;
  }
}

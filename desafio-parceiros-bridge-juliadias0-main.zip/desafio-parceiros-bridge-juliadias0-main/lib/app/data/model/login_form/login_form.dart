class LoginForm {
  final String? email;
  final String? password;

  LoginForm({
    this.email,
    this.password,
  });

  LoginForm copyWith({String? email, String? password}) {
    return LoginForm(
      email: email ?? this.email,
      password: password ?? this.password,
    );
  }
}

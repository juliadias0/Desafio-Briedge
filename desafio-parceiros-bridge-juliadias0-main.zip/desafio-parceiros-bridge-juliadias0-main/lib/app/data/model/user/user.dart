import 'package:parceiros_bridge/app/core/utils/date_time_utils.dart';
import 'package:parceiros_bridge/app/data/enums/user_type.dart';

class User {
  const User({
    required this.email,
    required this.password,
    required this.nickname,
    required this.userType,
    required this.birthDate,
    required this.registrationDate,
    required this.lastLoginDate,
  });

  final String email;
  final String password;
  final String nickname;
  final UserType userType;
  final DateTime birthDate;
  final DateTime registrationDate;
  final DateTime lastLoginDate;

  User copyWith({
    String? email,
    String? password,
    String? nickname,
    DateTime? birthDate,
    DateTime? lastLoginDate,
  }) {
    return User(
      email: email ?? this.email,
      password: password ?? this.password,
      nickname: nickname ?? this.nickname,
      userType: userType,
      birthDate: birthDate ?? this.birthDate,
      registrationDate: registrationDate,
      lastLoginDate: lastLoginDate ?? this.lastLoginDate,
    );
  }

  static User fromJson(Map<String, dynamic> json) {
    return User(
      email: json['email'],
      password: '',
      nickname: json['nickname'],
      userType: getUserTypeByName(json['userType'] ?? ''),
      birthDate: json.containsKey('birthDate') ? DateTime.parse(json['birthDate']) : DateTime.now().firstDayOfMonth,
      registrationDate: json.containsKey('registrationDate') ? DateTime.parse(json['registrationDate']) : DateTime.now().firstDayOfMonth,
      lastLoginDate: json.containsKey('lastLoginDate') ? DateTime.parse(json['lastLoginDate']) : DateTime.now().firstDayOfMonth,
    );
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['email'] = email;
    data['nickname'] = nickname;
    data['userType'] = userType.name;
    data['birthDate'] = birthDate.toIso8601String();
    data['registrationDate'] = registrationDate.toIso8601String();
    data['lastLoginDate'] = lastLoginDate.toIso8601String();

    return data;
  }

  // To protect users private data
  Map<String, dynamic> toQrCodeJson() {
    final data = <String, dynamic>{};
    data['nickname'] = nickname;
    data['userType'] = userType.name;
    data['registrationDate'] = registrationDate.toIso8601String();

    return data;
  }
}

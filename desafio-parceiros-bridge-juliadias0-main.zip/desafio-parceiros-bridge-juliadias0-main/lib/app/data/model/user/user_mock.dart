import 'package:parceiros_bridge/app/data/enums/user_type.dart';
import 'package:parceiros_bridge/app/data/model/user/user.dart';

// Mock DB while Firebase isn't implemented.
final userBridgerDavid = User(
  email: 'daviddavid@gmail.com',
  password: '12345',
  nickname: 'David',
  userType: UserType.bridger,
  birthDate: DateTime(1998, 7, 10),
  registrationDate: DateTime(2021, 10, 1),
  lastLoginDate: DateTime(2021, 10, 2),
);

final userBridgerFefa = User(
  email: 'fefafefa@gmail.com',
  password: '12356',
  nickname: 'Fefa',
  userType: UserType.bridger,
  birthDate: DateTime(1998, 10, 1),
  registrationDate: DateTime(2021, 9, 29),
  lastLoginDate: DateTime(2021, 10, 3),
);

final userPartnerCoxinhas = User(
  email: 'coxinhaboa@gmail.com',
  password: 'abcde',
  nickname: 'Coxinhas Top',
  userType: UserType.partner,
  birthDate: DateTime(1970, 1, 28),
  registrationDate: DateTime(2021, 10, 2),
  lastLoginDate: DateTime(2021, 10, 2),
);

final userPartnerPastel = User(
  email: 'pastelsuculento@gmail.com',
  password: 'xyz123',
  nickname: 'Pastelzao da raça',
  userType: UserType.partner,
  birthDate: DateTime(1980, 3, 14),
  registrationDate: DateTime(2021, 10, 1),
  lastLoginDate: DateTime(2021, 10, 3),
);

final userAdminNixon = User(
  email: 'nixonnixon@gmail.com',
  password: '232k1',
  nickname: 'Nixon',
  userType: UserType.admin,
  birthDate: DateTime(1986, 4, 25),
  registrationDate: DateTime(2021, 9, 20),
  lastLoginDate: DateTime(2021, 9, 30),
);

final users = [
  userBridgerDavid,
  userBridgerFefa,
  userPartnerCoxinhas,
  userPartnerPastel,
  userAdminNixon,
];

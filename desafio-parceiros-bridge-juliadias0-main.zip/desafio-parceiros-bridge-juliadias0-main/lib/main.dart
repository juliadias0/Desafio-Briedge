import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:parceiros_bridge/app/core/globals/global_bindings.dart';
import 'package:parceiros_bridge/app/core/theme/app_theme.dart';
import 'package:parceiros_bridge/app/modules/splash_screen/splash_screen_page.dart';
import 'package:parceiros_bridge/app/routes/pages.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  runApp(LaboratorioBridgeApp());
}

class LaboratorioBridgeApp extends StatelessWidget {
  final String? initialRoute;
  final GlobalBindings? globalBindings;

  const LaboratorioBridgeApp({
    this.initialRoute,
    this.globalBindings,
  });

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      enableLog: true,
      debugShowCheckedModeBanner: false,
      title: 'Laboratório Bridge',
      initialRoute: initialRoute ?? SplashScreenPage.ROUTE,
      initialBinding: globalBindings ?? GlobalBindings(),
      getPages: getAppPages(),
      theme: createTheme(),
      themeMode: ThemeMode.light,
    );
  }
}

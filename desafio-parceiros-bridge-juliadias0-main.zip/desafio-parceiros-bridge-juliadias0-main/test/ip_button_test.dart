import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Dummy test', (tester) async {
    await tester.pumpWidget(Container());
    expect(find.byType(Container), findsOneWidget);
  });
}

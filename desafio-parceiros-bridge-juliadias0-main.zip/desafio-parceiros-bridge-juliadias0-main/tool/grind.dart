import 'dart:convert';
import 'dart:io';

import 'package:async/async.dart' show StreamGroup;
import 'package:grinder/grinder.dart';

void main(List<String> args) => grind(args);

@Task('Generate dart files with build_runner (watch mode)')
watch() => flutter([
      'pub',
      'run',
      'build_runner',
      'watch',
      '--delete-conflicting-outputs',
    ]);

@Task('Generate dart files with build_runner (only once)')
build() => flutter([
      'pub',
      'run',
      'build_runner',
      'build',
      '--delete-conflicting-outputs',
    ]);

@Task('Runs (almost) all checks done by the CI')
ci() async {
  await flutter(['format', '--set-exit-if-changed', '-n', '.', '-l', '150']);
  await flutter(['analyze']);
  await flutter(['test', '--no-sound-null-safety']);
}

@Task('Delete build outputs and intemediate files')
clean() async {
  await flutter(['pub', 'run', 'build_runner', 'clean']);
  defaultClean();
  await flutter(['clean']);
  await flutter(['pub', 'get']);
}

Future<void> _log(Process process) async {
  final output = StreamGroup.merge([process.stdout, process.stderr]);
  await for (final message in output) {
    log(utf8.decode(message));
  }
}

Future<void> flutter(List<String> subcommands) async {
  final p = await Process.start(
    'flutter',
    subcommands,
  );

  await _log(p);

  final exit = await p.exitCode;

  if (exit != 0) {
    throw CommandError('Command exited with non-zero code ($exit)');
  }
}

class CommandError implements Exception {
  final String? message;

  CommandError([this.message]);

  @override
  String toString() {
    return 'CommandError: $message';
  }
}

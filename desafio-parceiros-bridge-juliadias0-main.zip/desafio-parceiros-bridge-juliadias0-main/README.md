# App Parceiros Bridge


Um aplicativo para integrar de forma fácil os colaboradores do bridge com os parceiros do laboratório. 

Desenvolvido para o processo seletivo 21_2.

Esse aplicativo usa a seguinte estrutura de arquivos: https://github.com/kauemurakami/getx_pattern

# Tarefas 
Tarefa 1: A versão do flutter do aplicativo está desatualizada. Atualize a versão do flutter do aplicativo para a última versão lançada (2.5.1).

Tarefa 2: Ordene a lista de descontos, de maneira decrescente, pela porcentagem de desconto aplicada.

Tarefa 3: Ordene a lista de parceiros, de maneira alfabética, pelo nome do parceiro.

Tarefa 4: Adicione o campo de telefone na tela de perfil.

Tarefa 5: Na tela de login, ao clicar em "Esqueceu a senha?", mostre uma dialog para informar um email de recuperação. O campo deve ser validado se está preenchido antes de enviar. Não é necessário implementar o envio do email, ao terminar, basta voltar para a tela de login.

Tarefa 6: Alterar o valor máximo de um desconto na listagem de descontos para 50%.

### Bônus
**Hard mode**: Mostre o telefone do parceiro na listagem de parceiros.

**Nightmare mode**: Implemente a seguinte tarefa:

User Story: Eu como usuário parceiro quero cadastrar novos descontos.

Critérios de aceitação:
- Deve ser possível informar o percentual do desconto;
- Deve ser possível informar a descrição do desconto;
- A tela de cadastro deve ser acessível através de um FAB na listagem de descontos;
- Não deve ser possível cadastrar um desconto sem percentual ou sem descrição;
- Não deve ser possível cadastrar um percentual inferior a 0 ou maior que 100;

Contra escopo:
- Não devem haver outros campos no cadastro;
- Não deve editar descontos já cadastrados;
- Não é necessária a implementação do cadastro, ao validar basta voltar à tela de listagem de descontos.

# Links úteis 
- https://flutter.dev/docs/get-started/install 
- https://dart.dev/guides/language/language-tour 
- https://flutter.dev/docs/development/ui/widgets-intro 
- https://flutter.dev/docs/development/ui/layout/tutorial 
- https://flutter.dev/docs/development/ui/interactive 
- https://flutter.dev/docs/cookbook 
- https://product.hubspot.com/blog/git-and-github-tutorial-for-beginners 
- https://rogerdudler.github.io/git-guide/

